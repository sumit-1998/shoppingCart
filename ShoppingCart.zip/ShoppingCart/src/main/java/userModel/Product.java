package userModel;

public class Product 
{
      int productId;
      String name;
      String price; 
      String brand;
      String description;
      String specification;
      String ratingAndReview;
      String quantity;
      String images;
      String seller;
      public String getImages() {
		return null;
	}
	public void setImages(String images) {
		this.images = images;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getRatingAndReview() {
		return ratingAndReview;
	}
	public void setRatingAndReview(String ratingAndReview) {
		this.ratingAndReview = ratingAndReview;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	
	
	
      
}
